import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { founder, consultation, phoneNumber, files } = body

    const backendResponse = await fetch(`${process.env.FASTAPI_BACKEND_URL}/consultation/request`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.BACKEND_API_KEY}`, // Add if needed
      },
      body: JSON.stringify({
        founder_id: founder,
        consultation_text: consultation,
        phone_number: phoneNumber,
        uploaded_files: files,
        timestamp: new Date().toISOString(),
      }),
    })

    if (!backendResponse.ok) {
      throw new Error("Backend request failed")
    }

    const result = await backendResponse.json()

    return NextResponse.json({
      success: true,
      message: "Consultation request submitted successfully",
      consultation_id: result.consultation_id,
    })
  } catch (error) {
    console.error("Consultation request error:", error)
    return NextResponse.json({ success: false, message: "Failed to submit consultation request" }, { status: 500 })
  }
}
